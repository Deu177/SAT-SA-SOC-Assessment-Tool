# SAT-SA — Supervisory Analytics Tool for SOC Assessment
SIH26157 | 2nd-year cybersecurity academic prototype

## Run on Windows PowerShell
1. Extract the ZIP. Open PowerShell inside the `SAT-SA_SOC_Project` folder (the folder containing `app.py`).
2. Run:
```powershell
py -m venv venv
venv\Scripts\activate
py -m pip install -r requirements.txt
py app.py
```
3. Open http://127.0.0.1:5000

If `No module named detection` appears, make sure your terminal is in the project root and that `detection\__init__.py` exists next to `app.py`.

## Demo workflow
Dashboard → Import CSV → Logs → Alerts → Evidence Review → Create Incident → Resolve → Analytics → Report. The first run loads `data/sample_logs.csv`.

## New feature: Evidence-to-Decision Review
Open **Evidence Review** to document four checks for each alert: source logs reviewed, affected scope checked, impact assessed, and response/action documented. Add analyst notes and choose a review outcome. Analytics and reports flag closed alerts that lack a complete checklist. This is a transparent review aid, not an automatic verdict; decisions remain with a human reviewer.

## Seven presentation objectives covered
1. Analyse structured event, alert and incident records.
2. Flag High/Critical alerts that have no linked incident as possible escalation gaps.
3. Flag blank required event fields and show absent event families as possible monitoring blind spots.
4. Flag Critical alerts closed in under five minutes for human review. Closure timestamps are recorded when an alert is changed to Closed.
5. Explain each rule-based supervisory finding and recommendation.
6. Rank alerts for manual review using severity/score, open status and missing incident linkage; the score is transparent and illustrative.
7. Include metrics, findings, recommendations and priority queue in the report (use Print / Save as PDF).

## CSV import format
Required columns: `timestamp,source_ip,destination_ip,username,event_type,action,message`. Keep the header names unchanged. Sample file: `data/sample_logs.csv`.

## Important limitations
This project uses synthetic/sample logs and rule-based checks. An absent event family may indicate a coverage gap but is not proof. Quick closure is a review indicator, not proof of misconduct. The assessment score is a prototype indicator, not a real SOC certification. Evidence checklist entries are user-entered and are not independently verified by this demo. Do not connect to real systems without authorization and security review.
