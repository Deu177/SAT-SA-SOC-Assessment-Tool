from datetime import datetime

def _dt(value):
    try:
        return datetime.fromisoformat((value or '').replace('Z', '+00:00'))
    except (ValueError, TypeError):
        return None

def analyze_supervision(events, alerts, incidents):
    """Explainable rule-based supervisory checks for academic SOC records."""
    findings=[]
    # Objective 3: incomplete evidence and coverage gaps
    fields=('timestamp','source_ip','destination_ip','username','event_type','action','message')
    incomplete=[]
    for e in events:
        missing=[f for f in fields if not str(e[f] or '').strip()]
        if missing:
            incomplete.append({'event_id':e['id'],'missing':missing})
    if incomplete:
        findings.append({'objective':'Missing records / evidence','severity':'High','count':len(incomplete),'detail':f'{len(incomplete)} event record(s) have blank required fields. Review event IDs: '+', '.join(str(x['event_id']) for x in incomplete[:12])+'.','recommendation':'Check the source export and restore required fields before relying on these records.'})
    # Coverage proxy: expected log families absent from the imported dataset
    types={str(e['event_type'] or '').lower() for e in events}
    families={'authentication':{'authentication','login','auth'},'network':{'network','port_scan','scan','firewall','connection'},'endpoint/process':{'endpoint','process','malware','system'}}
    absent=[name for name,aliases in families.items() if not types.intersection(aliases)]
    if events and absent:
        findings.append({'objective':'Monitoring blind spots','severity':'Medium','count':len(absent),'detail':'No imported event types were found for: '+', '.join(absent)+'. This is a possible coverage gap, not proof that monitoring is absent.','recommendation':'Confirm required log sources are connected and reporting during the selected period.'})
    # Objective 2: high-priority alerts not escalated to an incident
    incident_alert_ids={i['alert_id'] for i in incidents if i['alert_id'] is not None}
    untracked=[a for a in alerts if a['severity'] in ('Critical','High') and a['id'] not in incident_alert_ids]
    if untracked:
        findings.append({'objective':'Investigation / escalation weakness','severity':'High','count':len(untracked),'detail':f'{len(untracked)} High/Critical alert(s) have no linked incident: '+', '.join('#'+str(a['id']) for a in untracked[:12])+'.','recommendation':'Review each alert and create an incident or document why escalation was not required.'})
    # Objective 4: critical alert closed in under five minutes after creation
    quick=[]
    for a in alerts:
        if a['severity']=='Critical' and a['status']=='Closed' and a['closed_at']:
            start,end=_dt(a['created_at']),_dt(a['closed_at'])
            if start and end and 0 <= (end-start).total_seconds() < 300:
                quick.append(a['id'])
    if quick:
        findings.append({'objective':'Unusual rapid closure','severity':'High','count':len(quick),'detail':'Critical alert(s) closed in under five minutes: '+', '.join('#'+str(x) for x in quick)+'.','recommendation':'Check timestamps, evidence, analyst notes and approval trail; rapid closure is a review indicator, not proof of misconduct.'})
    # Objective 5/6: transparent, explainable review priorities
    priorities=[]
    for a in alerts:
        score=int(a['score'] or 0)
        reasons=[]
        if a['severity']=='Critical' or score>=80: reasons.append('critical/high risk score')
        if a['status']=='Open': reasons.append('still open')
        if a['severity'] in ('High','Critical') and a['id'] not in incident_alert_ids: reasons.append('no linked incident')
        priority=min(100,score+(15 if a['status']=='Open' else 0)+(10 if a['severity'] in ('High','Critical') and a['id'] not in incident_alert_ids else 0))
        if reasons: priorities.append({'alert_id':a['id'],'rule_name':a['rule_name'],'severity':a['severity'],'status':a['status'],'priority_score':priority,'reasons':', '.join(reasons)})
    priorities.sort(key=lambda x:(-x['priority_score'],x['alert_id']))
    if not findings:
        findings.append({'objective':'Supervisory checks','severity':'Low','count':0,'detail':'No findings were raised by the current checks. This does not prove the SOC is risk-free.','recommendation':'Continue sampling records and validate log-source coverage.'})
    return {'findings':findings,'priorities':priorities,'incomplete_records':incomplete,'missing_log_families':absent}
