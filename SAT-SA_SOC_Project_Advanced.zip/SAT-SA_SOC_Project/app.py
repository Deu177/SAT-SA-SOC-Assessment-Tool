from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from pathlib import Path
from datetime import datetime, timezone
import sqlite3, os
from detection.log_parser import parse_csv_text
from detection.detection_engine import detect_events
from analytics.metrics import calculate_metrics
from analytics.assessment import calculate_assessment
from analytics.supervision import analyze_supervision
from reports.report_generator import generate_report

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=BASE_DIR/'database'/'soc.db'
DB_PATH.parent.mkdir(exist_ok=True)
app=Flask(__name__)
app.secret_key=os.environ.get('SAT_SA_SECRET_KEY','sat-sa-demo-change-this')

def db():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,timestamp TEXT,source_ip TEXT,destination_ip TEXT,username TEXT,event_type TEXT,action TEXT,message TEXT,raw TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,event_id INTEGER,rule_id TEXT,rule_name TEXT,severity TEXT,score INTEGER,reason TEXT,status TEXT DEFAULT 'Open',created_at TEXT,closed_at TEXT);
    CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,alert_id INTEGER,title TEXT,severity TEXT,status TEXT DEFAULT 'Open',analyst TEXT,notes TEXT,opened_at TEXT,resolved_at TEXT);
    CREATE TABLE IF NOT EXISTS alert_evidence(alert_id INTEGER PRIMARY KEY, logs_reviewed INTEGER DEFAULT 0, scope_checked INTEGER DEFAULT 0, impact_assessed INTEGER DEFAULT 0, response_documented INTEGER DEFAULT 0, analyst_notes TEXT DEFAULT '', decision TEXT DEFAULT 'Pending review', updated_at TEXT, FOREIGN KEY(alert_id) REFERENCES alerts(id));
    ''');
    cols={r['name'] for r in c.execute('PRAGMA table_info(alerts)').fetchall()}
    if 'closed_at' not in cols: c.execute('ALTER TABLE alerts ADD COLUMN closed_at TEXT')
    c.commit(); c.close()

def ingest(text):
    c=db(); events=parse_csv_text(text); now=datetime.now(timezone.utc).isoformat(); inserted=[]
    for e in events:
        cur=c.execute('INSERT INTO events(timestamp,source_ip,destination_ip,username,event_type,action,message,raw,created_at) VALUES(?,?,?,?,?,?,?,?,?)', (e['timestamp'],e['source_ip'],e['destination_ip'],e['username'],e['event_type'],e['action'],e['message'],e['raw'],now)); inserted.append({**e,'id':cur.lastrowid})
    detections=detect_events(inserted)
    for d in detections:
        c.execute('INSERT INTO alerts(event_id,rule_id,rule_name,severity,score,reason,status,created_at) VALUES(?,?,?,?,?,?,?,?)',(d['event_id'],d['rule_id'],d['rule_name'],d['severity'],d['score'],d['reason'],'Open',now))
    c.commit(); c.close(); return len(events),len(detections)

def seed():
    c=db()
    if c.execute('SELECT COUNT(*) FROM events').fetchone()[0]: c.close(); return
    p=BASE_DIR/'data'/'sample_logs.csv'
    c.close(); ingest(p.read_text(encoding='utf-8'))

@app.route('/')
def dashboard():
    c=db(); stats={k:c.execute(q).fetchone()[0] for k,q in {'events':'SELECT COUNT(*) FROM events','alerts':'SELECT COUNT(*) FROM alerts','open_alerts':"SELECT COUNT(*) FROM alerts WHERE status='Open'",'incidents':'SELECT COUNT(*) FROM incidents','open_incidents':"SELECT COUNT(*) FROM incidents WHERE status!='Resolved'"}.items()}; alerts=c.execute('SELECT a.*,e.timestamp,e.source_ip,e.username,e.event_type FROM alerts a LEFT JOIN events e ON e.id=a.event_id ORDER BY a.id DESC LIMIT 8').fetchall(); c.close(); return render_template('dashboard.html',stats=stats,alerts=alerts)

@app.route('/logs')
def logs():
    c=db(); rows=c.execute('SELECT * FROM events ORDER BY id DESC LIMIT 200').fetchall(); c.close(); return render_template('logs.html',rows=rows)

@app.route('/upload',methods=['GET','POST'])
def upload():
    if request.method=='POST':
        f=request.files.get('logfile')
        if not f: flash('Select a CSV file.','danger'); return redirect(url_for('upload'))
        try:
            n,a=ingest(f.read().decode('utf-8-sig')); flash(f'Imported {n} events and generated {a} alerts.','success')
        except Exception as e: flash(f'Import failed: {e}','danger')
        return redirect(url_for('dashboard'))
    return render_template('upload.html')

@app.route('/alerts')
def alerts():
    c=db(); rows=c.execute('SELECT a.*,e.timestamp,e.source_ip,e.destination_ip,e.username,e.event_type,e.message FROM alerts a LEFT JOIN events e ON e.id=a.event_id ORDER BY a.id DESC').fetchall(); c.close(); return render_template('alerts.html',rows=rows)

@app.post('/alerts/<int:alert_id>/status')
def alert_status(alert_id):
    s=request.form.get('status','Open'); s=s if s in {'Open','Investigating','Closed'} else 'Open'; c=db(); closed_at=datetime.now(timezone.utc).isoformat() if s=='Closed' else None; c.execute('UPDATE alerts SET status=?,closed_at=? WHERE id=?',(s,closed_at,alert_id)); c.commit(); c.close(); return redirect(url_for('alerts'))

@app.route('/incidents')
def incidents():
    c=db(); rows=c.execute('SELECT i.*,a.rule_name,a.score,a.reason FROM incidents i LEFT JOIN alerts a ON a.id=i.alert_id ORDER BY i.id DESC').fetchall(); c.close(); return render_template('incidents.html',rows=rows)

@app.post('/incidents/create/<int:alert_id>')
def create_incident(alert_id):
    c=db(); a=c.execute('SELECT * FROM alerts WHERE id=?',(alert_id,)).fetchone()
    if not a: c.close(); flash('Alert not found.','danger'); return redirect(url_for('alerts'))
    now=datetime.now(timezone.utc).isoformat(); c.execute('INSERT INTO incidents(alert_id,title,severity,status,analyst,notes,opened_at) VALUES(?,?,?,?,?,?,?)',(alert_id,f"{a['rule_name']} - Alert #{alert_id}",a['severity'],'Open','Student Analyst','',now)); c.execute("UPDATE alerts SET status='Investigating' WHERE id=?",(alert_id,)); c.commit(); c.close(); return redirect(url_for('incidents'))

@app.post('/incidents/<int:incident_id>/resolve')
def resolve_incident(incident_id):
    c=db(); i=c.execute('SELECT alert_id FROM incidents WHERE id=?',(incident_id,)).fetchone(); now=datetime.now(timezone.utc).isoformat()
    if i: c.execute('UPDATE incidents SET status=\'Resolved\',resolved_at=? WHERE id=?',(now,incident_id)); c.execute("UPDATE alerts SET status='Closed',closed_at=? WHERE id=?",(now,i['alert_id']))
    c.commit(); c.close(); return redirect(url_for('incidents'))

@app.route('/evidence')
def evidence():
    c=db()
    query = """SELECT a.*,e.timestamp,e.source_ip,e.username,e.event_type,
        COALESCE(v.logs_reviewed,0) AS logs_reviewed,
        COALESCE(v.scope_checked,0) AS scope_checked,
        COALESCE(v.impact_assessed,0) AS impact_assessed,
        COALESCE(v.response_documented,0) AS response_documented,
        COALESCE(v.analyst_notes,'') AS analyst_notes,
        COALESCE(v.decision,'Pending review') AS decision, v.updated_at
        FROM alerts a LEFT JOIN events e ON e.id=a.event_id
        LEFT JOIN alert_evidence v ON v.alert_id=a.id ORDER BY a.id DESC"""
    rows=c.execute(query).fetchall(); c.close()
    keys=('logs_reviewed','scope_checked','impact_assessed','response_documented')
    reviewed=sum(1 for r in rows if all(r[k] for k in keys))
    return render_template('evidence.html',rows=rows,reviewed=reviewed,total=len(rows))

@app.post('/evidence/<int:alert_id>')
def save_evidence(alert_id):
    c=db()
    if not c.execute('SELECT id FROM alerts WHERE id=?',(alert_id,)).fetchone():
        c.close(); flash('Alert not found.','danger'); return redirect(url_for('evidence'))
    keys=('logs_reviewed','scope_checked','impact_assessed','response_documented')
    values=[int(request.form.get(k)=='on') for k in keys]
    notes=request.form.get('analyst_notes','').strip()[:2000]
    decision=request.form.get('decision','Pending review')
    if decision not in {'Pending review','Escalate','False positive - verified','Resolved with evidence'}: decision='Pending review'
    now=datetime.now(timezone.utc).isoformat()
    query = """INSERT INTO alert_evidence(alert_id,logs_reviewed,scope_checked,impact_assessed,response_documented,analyst_notes,decision,updated_at)
    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(alert_id) DO UPDATE SET logs_reviewed=excluded.logs_reviewed,scope_checked=excluded.scope_checked,impact_assessed=excluded.impact_assessed,response_documented=excluded.response_documented,analyst_notes=excluded.analyst_notes,decision=excluded.decision,updated_at=excluded.updated_at"""
    c.execute(query,(alert_id,*values,notes,decision,now)); c.commit(); c.close()
    flash(f'Evidence review saved for alert #{alert_id}.','success'); return redirect(url_for('evidence'))

@app.route('/analytics')
def analytics():
    c=db(); ev=c.execute('SELECT * FROM events').fetchall(); al=c.execute('SELECT * FROM alerts').fetchall(); inc=c.execute('SELECT * FROM incidents').fetchall(); m=calculate_metrics(ev,al,inc); a=calculate_assessment(m); sup=analyze_supervision(ev,al,inc)
    evidence_rows=c.execute('SELECT * FROM alert_evidence').fetchall()
    evidence_by={r['alert_id']:r for r in evidence_rows}
    keys=('logs_reviewed','scope_checked','impact_assessed','response_documented')
    gaps=[x['id'] for x in al if x['status']=='Closed' and (x['id'] not in evidence_by or not all(evidence_by[x['id']][k] for k in keys))]
    if gaps:
        sup['findings'].append({'objective':'Decision evidence gap','severity':'High','count':len(gaps),'detail':f'{len(gaps)} closed alert(s) do not have all four evidence checks completed: '+', '.join('#'+str(x) for x in gaps[:12])+'.','recommendation':'Review source logs, affected scope, impact and response records. Complete the checklist or document why an item is not applicable.'})
    c.close(); return render_template('analytics.html',metrics=m,assessment=a,supervision=sup)

@app.route('/report')
def report():
    c=db(); ev=c.execute('SELECT * FROM events').fetchall(); al=c.execute('SELECT * FROM alerts').fetchall(); inc=c.execute('SELECT * FROM incidents').fetchall(); m=calculate_metrics(ev,al,inc); a=calculate_assessment(m); sup=analyze_supervision(ev,al,inc)
    evrows=c.execute('SELECT * FROM alert_evidence').fetchall(); evid={r['alert_id']:r for r in evrows}
    keys=('logs_reviewed','scope_checked','impact_assessed','response_documented')
    gaps=[x['id'] for x in al if x['status']=='Closed' and (x['id'] not in evid or not all(evid[x['id']][k] for k in keys))]
    if gaps: sup['findings'].append({'objective':'Decision evidence gap','severity':'High','count':len(gaps),'detail':f'{len(gaps)} closed alert(s) lack a complete evidence checklist: '+', '.join('#'+str(x) for x in gaps[:12])+'.','recommendation':'Review and complete the evidence checklist before treating closure as fully documented.'})
    html=generate_report(m,a,al,sup); c.close(); return render_template('report.html',report_html=html)

@app.get('/api/stats')
def api_stats():
    c=db(); x={'events':c.execute('SELECT COUNT(*) FROM events').fetchone()[0],'alerts':c.execute('SELECT COUNT(*) FROM alerts').fetchone()[0],'incidents':c.execute('SELECT COUNT(*) FROM incidents').fetchone()[0]}; c.close(); return jsonify(x)

@app.post('/reset-demo')
def reset_demo():
    c=db(); c.executescript('DELETE FROM incidents;DELETE FROM alert_evidence;DELETE FROM alerts;DELETE FROM events;'); c.commit(); c.close(); seed(); return redirect(url_for('dashboard'))

if __name__=='__main__': init_db(); seed(); app.run(debug=True)
